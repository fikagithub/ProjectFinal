<?php $__env->startSection('main'); ?>
    <div class="categories-list">
        <h1>Categories List</h1>
        <?php echo $__env->make('includes.flash-message', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="item">
                <p><?php echo e($category->name); ?></p>
                <div>
                    <a href="<?php echo e(route('categories.edit', $category)); ?>">Edit</a>
                </div>
                <form action="<?php echo e(route('categories.destroy', $category)); ?>" method="post">
                    <?php echo method_field('delete'); ?>
                    <?php echo csrf_field(); ?>
                    <input type="submit" value="Delete">
                </form>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <div class="index-categories">
            <a href="<?php echo e(route('categories.create')); ?>">Create category<span>&#8594;</span></a>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\Praktikum-laravel2\Laravel-8-Blog-Tutorial-up-to-Deployment-main\resources\views/categories/index-categories.blade.php ENDPATH**/ ?>