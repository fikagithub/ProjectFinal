<p>Message:</p>
<p><?php echo e($data['message']); ?></p>

<div style="margin-top: 50px;">
<p>Name: <?php echo e($data['name']); ?> </p>
<p>Email: <?php echo e($data['email']); ?></p>
</div><?php /**PATH C:\laragon\www\Praktikum-laravel2\Laravel-8-Blog-Tutorial-up-to-Deployment-main\resources\views/mail/mail.blade.php ENDPATH**/ ?>