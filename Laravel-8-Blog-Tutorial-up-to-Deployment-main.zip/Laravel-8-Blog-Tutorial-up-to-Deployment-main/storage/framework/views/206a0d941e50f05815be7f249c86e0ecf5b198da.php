<?php $__env->startSection('main'); ?>
  
    <!-- main -->
    <main class="container">
      <section class="single-blog-post">
        <h1>About UKM Sanggar Seni</h1>
        <div class="single-blog-post-ContentImage" data-aos="fade-left">
          <img src="<?php echo e(asset('images/sanggar.jpg')); ?>" alt="" />
        </div>

        <div>
          <p class="about-text">
            Lorem ipsum dolor sit, amet consectetur adipisicing elit. Nam, ut
            tempore repellat molestias a distinctio fuga molestiae eaque
            laborum vero eos, maiores fugit culpa porro delectus aliquam
            adipisci nisi voluptas sequi odit, numquam architecto officia?
            Corrupti recusandae beatae sint quasi iste libero maiores commodi
            odio molestias vel fugit, omnis nobis consectetur harum veritatis
            necessitatibus asperiores officiis. Dolores nemo voluptates.
            <br /><br />
            Adipisicing elit. Illum reprehenderit sapiente at ab amet, nobis
            porro pariatur similique dicta nisi velit fugiat reiciendis, quos
            fuga nemo aliquam aspernatur est vel. Lorem ipsum dolor sit amet
            consectetur, adipisicing elit. Omnis non ad veritatis. Lorem ipsum
            dolor sit amet consectetur, adipisicing elit. Lorem ipsum dolor
            sit.
          </p>
        </div>
      </section>
    </main>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\Praktikum-laravel2\Laravel-8-Blog-Tutorial-up-to-Deployment-main\resources\views/about.blade.php ENDPATH**/ ?>